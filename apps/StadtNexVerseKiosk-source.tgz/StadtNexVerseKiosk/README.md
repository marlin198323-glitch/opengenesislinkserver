# Stadt NexVerse Live – Android Kiosk (Lenovo-Tablet)

Android-Nativ-App für ein stationäres Tablet-Dashboard im Querformat mit echter
Device-Owner-/Lock-Task-Kioskunterstützung.

## Neon-Design v1.1.0

- Die freigegebene Stadt-NexVerse-Vorlage mit drei Figuren wird unverfremdet als
  Kopfbereich verwendet. Darunter liegen **echte**, dynamische Android-Anzeigen.
- Sechs Statuskarten, große Berlin-Uhr, Live-Verlaufsdiagramm auf Basis tatsächlich
  abgerufener Daten, API-Health-Anzeige und sechs umschaltbare Informationsansichten.
- Die öffentliche World API liefert derzeit **keine vollständige Zahl aktiver
  Regionen** und keinen separaten Asset-/Grid-Dienststatus. Solche Daten werden
  bewusst nicht erfunden. Die Kachel zeigt stattdessen Heimatgrids online.
- Bei Verbindungsfehlern erscheinen keine erfundenen Online-Zahlen.
- Administrator: **Stadt-NexVerse-Schriftzug links oben für mind. 0,65 Sekunden
  gedrückt halten**, anschließend PIN eingeben.

## Funktionen

- große Uhr inklusive Sekunden und Datum (Zeitzone Europe/Berlin)
- aktuelle Einwohner (`residents.online_now`)
- aktuelle Hypergrid-Gäste (`hypergrid.online_now`)
- Grid-Nutzer insgesamt (`online.total`)
- registrierte Einwohner (`residents.registered_total`)
- bekannte HG-Besucher (`hypergrid.known_visitors_total`)
- aktive Herkunfts-Grids (`hypergrid.home_grids_online_now`)
- Aktualisierung alle 15 Sekunden (HTTPS, keine Tokens auf dem Tablet)
- Verbindungsstatus / sichtbarer Hinweis bei veralteten Werten
- 24/7 Display an; Querformat, Immersive Fullscreen; Admin-PIN mit PBKDF2
- Lock Task + Launcher-Override nur wenn die App Device Owner ist
- BootReceiver startet App bei Neustart des verwalteten Tablets

## Android-Anforderungen

- Android 6 / API 23 oder neuer, optimiert für Querformat-Tablets
- HTTPS-Zugang zur **öffentlichen** OGL World API (Statistikaggregate)
- Es sind keine Datenbank-Zugangsdaten und kein World-API-Adminschlüssel nötig.

## APK selbst bauen

Android Studio öffnen: Ordner `StadtNexVerseKiosk` auswählen. Alternativ:

```bash
# Voraussetzungen: JDK 17, Android SDK 35, Gradle 8.9
cd StadtNexVerseKiosk
gradle :app:assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

Der CI-Workflow unter `.github/workflows/build-apk.yml` baut eine Debug-APK
und stellt sie als Actions-Artefakt bereit. Debug-APKs eignen sich zum Testen,
nicht zur Play-Store-Veröffentlichung. Für ein Update muss mit einem stabilen
Release-Schlüssel signiert werden; CI-Debugsignaturen können wechseln.

## Ersteinrichtung

1. APK auf dem Tablet installieren. Android kann die Erlaubnis für Apps aus
   dieser Quelle verlangen.
2. App öffnen und HTTPS-URL der World API eingeben. Ein Host wie
   `https://example.org` wird um `/api/v1/statistics/summary` ergänzt.
3. Individuelle Admin-PIN (6–16 Ziffern) setzen und Dashboard starten.
4. Oben links den Schriftzug **STADT NEXVERSE** lange drücken, um die PIN-Abfrage
   und die Konfiguration zu öffnen.

Wichtig: Die World API muss öffentliche aggregierte Statistiken zulassen.
Falls die API `401`, `403` oder `503` liefert, als Erstes die Serverkonfiguration
und die Backend-Datendienste prüfen. Verbindungsfehler zeigen keinen erfundenen
Online-Wert; wenn vorher Daten vorlagen, bleiben sie als *letzte verfügbare Werte*
sichtbar.

## Echten gesperrten Kiosk-Modus einrichten

**Vorsicht:** Device Owner hat weitreichende Geräteverwaltung. Nur auf einem
speziell dafür bestimmten, persönlich verwalteten Tablet aktivieren.

1. Daten des Tablets sichern. Die Device-Owner-Zuweisung erfordert ein
   geeignetes, in der Regel frisch zurückgesetztes bzw. noch nicht vollständig
   eingerichtetes Android-Gerät, ohne widersprechende Nutzer/Arbeitsprofile oder
   vorhandenen Device Owner. Der Vorgang kann je nach Android-/Lenovo-Version
   eingeschränkt sein.
2. USB-Debugging aktivieren, Gerät mit Rechner verbinden.
3. APK installieren:

```bash
adb devices
adb install -r app-debug.apk
adb shell dpm set-device-owner de.stadtnexverse.kiosk/.KioskDeviceAdminReceiver
```

4. App starten, HTTPS-URL und Admin-PIN konfigurieren und Kiosk aktivieren.
   Beim nächsten App-Start werden Lock Task und die bevorzugte HOME-Aktivität
   eingerichtet. Das Tablet bleibt dann in dieser App.
5. Beenden: Schriftzug oben links lange drücken, PIN eingeben,
   **Kiosk deaktivieren und App schließen** wählen. Die HOME-Zuweisung und
   die Lock-Task-Allowlist werden dabei entfernt.

**Ohne Device Owner** gibt es weiterhin Immersive Fullscreen; die optionale
Android-Bildschirmfixierung zeigt einen systemseitigen Bestätigungsdialog.
Sie ist keine manipulationssichere Gerätesperre.

Bei einem verlorenen Admin-PIN ist möglicherweise eine administrative
Neuprovisionierung nötig. Es gibt bewusst keinen fest eingebauten Master-PIN.

## Datenschutz und Betrieb

Der Client liest nur die öffentlich abrufbare aggregierte Statistik. Er
versendet keine persönlichen Avatar-Namen. Nutze einen eigenen HTTPS-Proxy
bzw. die OGL World API mit gültigem Zertifikat. Keine privaten API-Schlüssel
in der installierten APK hinterlegen. Kiosk-Geräte mit Android-Updates und
kontrolliertem Netz betreiben.
