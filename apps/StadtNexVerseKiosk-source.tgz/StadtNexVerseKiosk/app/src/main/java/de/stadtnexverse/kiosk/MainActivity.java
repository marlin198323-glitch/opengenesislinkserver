package de.stadtnexverse.kiosk;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Tablet-only statistics dashboard. No resident credentials or private details are used. */
public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(7, 16, 31);
    private static final int PANEL = Color.rgb(15, 30, 53);
    private static final int PALE = Color.rgb(220, 232, 247);
    private static final int MUTED = Color.rgb(135, 159, 185);
    private static final int CYAN = Color.rgb(78, 214, 236);
    private static final int GOLD = Color.rgb(244, 188, 108);
    private static final int GREEN = Color.rgb(105, 225, 166);
    private static final int AMBER = Color.rgb(255, 189, 90);
    private static final int POLL_MS = 15000;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private final AtomicBoolean loading = new AtomicBoolean(false);
    private SharedPreferences prefs;
    private DevicePolicyManager policy;
    private ComponentName admin;
    private boolean showingSettings;
    private boolean initialSetup;
    private boolean online;
    private long lastUpdateMillis;
    private TextView clockLabel, dateLabel, statusLabel, lastUpdateLabel, lockLabel;
    private TextView[] valueLabels;
    private final String[] lastValues = { "—", "—", "—", "—", "—", "—" };

    private final Runnable clockTick = new Runnable() {
        @Override public void run() {
            if (!showingSettings) updateClock();
            handler.postDelayed(this, 1000);
        }
    };
    private final Runnable pollTick = new Runnable() {
        @Override public void run() {
            if (!showingSettings) refresh();
            handler.postDelayed(this, POLL_MS);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("kiosk", MODE_PRIVATE);
        policy = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        admin = new ComponentName(this, KioskDeviceAdminReceiver.class);
        showingSettings = !prefs.contains("api_url") || !prefs.contains("pin_hash");
        initialSetup = showingSettings;
        if (showingSettings) renderSettings(); else renderDashboard();
        handler.post(clockTick);
        handler.post(pollTick);
    }

    @Override protected void onResume() {
        super.onResume();
        immersive();
        if (!showingSettings) handler.postDelayed(this::tryStartDedicatedKiosk, 450);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(clockTick);
        handler.removeCallbacks(pollTick);
        network.shutdownNow();
        super.onDestroy();
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) immersive();
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private int dp(float n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }
    private TextView text(String value, float size, int color, boolean bold) {
        TextView label = new TextView(this);
        label.setText(value);
        label.setTextColor(color);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        label.setGravity(Gravity.CENTER_VERTICAL);
        label.setFontFeatureSettings("tnum");
        if (bold) label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return label;
    }
    private GradientDrawable rounded(int fill, int stroke, int radius) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(fill);
        bg.setCornerRadius(dp(radius));
        if (stroke != 0) bg.setStroke(dp(1), stroke);
        return bg;
    }
    private LinearLayout horizontal() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }
    private LinearLayout vertical() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }
    private LinearLayout.LayoutParams lp(int width, int height) {
        return new LinearLayout.LayoutParams(width == -1 ? -1 : dp(width), height == -1 ? -1 : dp(height));
    }
    private LinearLayout.LayoutParams weight(float amount) {
        return new LinearLayout.LayoutParams(0, -1, amount);
    }

    private void renderDashboard() {
        showingSettings = false;
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        root.addView(new CityBackdrop(this), new FrameLayout.LayoutParams(-1, -1));
        LinearLayout content = vertical();
        content.setPadding(dp(26), dp(18), dp(26), dp(14));
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        immersive();

        LinearLayout header = horizontal();
        header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout brand = vertical();
        TextView title = text("STADT NEXVERSE", 23, PALE, true);
        title.setLetterSpacing(0.09f);
        brand.addView(title);
        TextView subtitle = text("LIVE  ·  GRID MONITOR", 11, CYAN, true);
        subtitle.setLetterSpacing(0.19f);
        brand.addView(subtitle);
        brand.setOnLongClickListener(v -> { promptForAdminPin(); return true; });
        header.addView(brand, new LinearLayout.LayoutParams(0, dp(58), 1));
        statusLabel = text("VERBINDE …", 12, AMBER, true);
        statusLabel.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        header.addView(statusLabel);
        content.addView(header, lp(-1, 60));

        View line = new View(this);
        line.setBackgroundColor(Color.rgb(47, 77, 104));
        LinearLayout.LayoutParams lineParams = lp(-1, 1);
        lineParams.topMargin = dp(4);
        lineParams.bottomMargin = dp(15);
        content.addView(line, lineParams);

        LinearLayout main = horizontal();
        LinearLayout.LayoutParams mainParams = new LinearLayout.LayoutParams(-1, 0, 1);
        content.addView(main, mainParams);
        LinearLayout clockPanel = vertical();
        clockPanel.setGravity(Gravity.CENTER_VERTICAL);
        clockPanel.setPadding(dp(22), dp(10), dp(12), dp(10));
        clockPanel.setBackground(rounded(Color.argb(165, 15, 33, 58), Color.rgb(38, 79, 105), 18));
        LinearLayout.LayoutParams clockParams = new LinearLayout.LayoutParams(0, -1, 0.95f);
        clockParams.rightMargin = dp(14);
        main.addView(clockPanel, clockParams);
        TextView clockTitle = text("AKTUELLE UHRZEIT", 12, GOLD, true);
        clockTitle.setLetterSpacing(0.14f);
        clockPanel.addView(clockTitle);
        clockLabel = text("--:--:--", 47, PALE, true);
        clockLabel.setSingleLine(true);
        if (Build.VERSION.SDK_INT >= 26) {
            clockLabel.setAutoSizeTextTypeUniformWithConfiguration(20, 56, 1, TypedValue.COMPLEX_UNIT_SP);
        }
        LinearLayout.LayoutParams clockP = lp(-1, 105);
        clockP.topMargin = dp(6);
        clockPanel.addView(clockLabel, clockP);
        dateLabel = text("", 14, MUTED, false);
        clockPanel.addView(dateLabel);
        TextView zone = text("EUROPA / BERLIN", 11, CYAN, true);
        LinearLayout.LayoutParams zoneP = lp(-1, 42);
        clockPanel.addView(zone, zoneP);
        View clockLine = new View(this);
        clockLine.setBackgroundColor(Color.rgb(48, 76, 107));
        LinearLayout.LayoutParams clockLineP = lp(-1, 1);
        clockLineP.topMargin = dp(16);
        clockLineP.bottomMargin = dp(14);
        clockPanel.addView(clockLine, clockLineP);
        lockLabel = text("", 12, MUTED, false);
        clockPanel.addView(lockLabel);

        LinearLayout metrics = vertical();
        main.addView(metrics, new LinearLayout.LayoutParams(0, -1, 1.85f));
        valueLabels = new TextView[6];
        String[] names = {
                "BEWOHNER ONLINE", "HYPERGRID ONLINE", "GESAMT ONLINE",
                "BEWOHNER REGISTRIERT", "HG BESUCHER BEKANNT", "HEIMATGRIDS ONLINE"
        };
        String[] icons = { "●", "◆", "●", "■", "◆", "◈" };
        for (int row = 0; row < 2; row++) {
            LinearLayout metricRow = horizontal();
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, 0, 1);
            if (row == 0) rowParams.bottomMargin = dp(10);
            metrics.addView(metricRow, rowParams);
            for (int col = 0; col < 3; col++) {
                int idx = row * 3 + col;
                int accent = idx == 2 ? GOLD : (idx == 1 || idx == 4 ? CYAN : GREEN);
                LinearLayout card = vertical();
                card.setPadding(dp(15), dp(14), dp(10), dp(8));
                card.setBackground(rounded(PANEL, Color.rgb(38, 67, 94), 16));
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -1, 1);
                if (col != 2) cp.rightMargin = dp(10);
                metricRow.addView(card, cp);
                TextView name = text(icons[idx] + "  " + names[idx], 10, MUTED, true);
                name.setMaxLines(2);
                card.addView(name);
                TextView value = text(lastValues[idx], 42, accent, true);
                if (Build.VERSION.SDK_INT >= 26) {
                    value.setAutoSizeTextTypeUniformWithConfiguration(19, 48, 1, TypedValue.COMPLEX_UNIT_SP);
                }
                value.setGravity(Gravity.CENTER_VERTICAL);
                card.addView(value, new LinearLayout.LayoutParams(-1, 0, 1));
                valueLabels[idx] = value;
                TextView source = text(idx < 3 ? "JETZT LIVE" : "GRID STATISTIK", 9, MUTED, false);
                card.addView(source);
            }
        }
        LinearLayout footer = horizontal();
        footer.setGravity(Gravity.CENTER_VERTICAL);
        lastUpdateLabel = text("Lade Live-Daten …", 11, MUTED, false);
        footer.addView(lastUpdateLabel, new LinearLayout.LayoutParams(0, dp(35), 1));
        TextView note = text("AUTO-REFRESH 15 SEK.   ·   ADMIN: TITEL LANG DRÜCKEN", 10, MUTED, false);
        note.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        footer.addView(note);
        content.addView(footer, lp(-1, 38));
        updateClock();
        updateStatus();
        tryStartDedicatedKiosk();
        refresh();
    }

    private void updateClock() {
        TimeZone tz = TimeZone.getTimeZone("Europe/Berlin");
        Date now = new Date();
        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss", Locale.GERMANY);
        format.setTimeZone(tz);
        if (clockLabel != null) clockLabel.setText(format.format(now));
        format = new SimpleDateFormat("EEEE, d. MMMM yyyy", Locale.GERMANY);
        format.setTimeZone(tz);
        if (dateLabel != null) dateLabel.setText(format.format(now));
    }

    private void updateStatus() {
        if (statusLabel == null || showingSettings) return;
        statusLabel.setText(online ? "●  LIVE VERBUNDEN" : "●  NICHT VERBUNDEN");
        statusLabel.setTextColor(online ? GREEN : AMBER);
        if (lockLabel != null) {
            String mode;
            if (isDeviceOwner() && prefs.getBoolean("kiosk_enabled", false))
                mode = "KIOSK GESPERRT  ·  DEVICE OWNER";
            else if (prefs.getBoolean("kiosk_enabled", false))
                mode = "VOLLBILD  ·  FIXIERUNG OPTIONAL";
            else mode = "VOLLBILD  ·  KIOSK DEAKTIVIERT";
            lockLabel.setText(mode);
        }
        if (lastUpdateLabel != null) {
            if (lastUpdateMillis == 0) {
                lastUpdateLabel.setText("Noch keine Live-Werte empfangen");
            } else {
                SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss", Locale.GERMANY);
                formatter.setTimeZone(TimeZone.getTimeZone("Europe/Berlin"));
                String prefix = online ? "Zuletzt aktualisiert: " : "Letzte verfügbare Werte: ";
                lastUpdateLabel.setText(prefix + formatter.format(new Date(lastUpdateMillis)));
            }
        }
    }

    private void refresh() {
        if (showingSettings || !loading.compareAndSet(false, true)) return;
        String configured = prefs.getString("api_url", "");
        network.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(configured);
                if (!"https".equalsIgnoreCase(url.getProtocol())) throw new IllegalArgumentException("HTTPS erforderlich");
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(7000);
                connection.setReadTimeout(9000);
                connection.setRequestProperty("Accept", "application/json");
                connection.setUseCaches(false);
                int status = connection.getResponseCode();
                if (status != 200) throw new IllegalStateException("HTTP " + status);
                StringBuilder body = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                    char[] chars = new char[2048];
                    int n;
                    while ((n = reader.read(chars)) > -1) {
                        body.append(chars, 0, n);
                        if (body.length() > 256 * 1024) throw new IllegalStateException("Antwort zu groß");
                    }
                }
                JSONObject root = new JSONObject(body.toString());
                JSONObject residents = root.getJSONObject("residents");
                JSONObject hypergrid = root.getJSONObject("hypergrid");
                JSONObject onlineData = root.getJSONObject("online");
                String[] values = {
                        String.valueOf(residents.getInt("online_now")),
                        String.valueOf(hypergrid.getInt("online_now")),
                        String.valueOf(onlineData.getInt("total")),
                        String.valueOf(residents.getInt("registered_total")),
                        String.valueOf(hypergrid.getInt("known_visitors_total")),
                        String.valueOf(hypergrid.getInt("home_grids_online_now"))
                };
                handler.post(() -> {
                    loading.set(false);
                    online = true;
                    lastUpdateMillis = System.currentTimeMillis();
                    System.arraycopy(values, 0, lastValues, 0, 6);
                    if (!showingSettings && valueLabels != null) {
                        for (int i = 0; i < 6; i++) valueLabels[i].setText(values[i]);
                    }
                    updateStatus();
                });
            } catch (Exception e) {
                handler.post(() -> {
                    loading.set(false);
                    online = false;
                    updateStatus();
                });
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private boolean isDeviceOwner() {
        return policy != null && policy.isDeviceOwnerApp(getPackageName());
    }
    private void tryStartDedicatedKiosk() {
        if (showingSettings || !prefs.getBoolean("kiosk_enabled", false) || !isDeviceOwner()) return;
        try {
            policy.setLockTaskPackages(admin, new String[] {getPackageName()});
            IntentFilter home = new IntentFilter(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME);
            home.addCategory(Intent.CATEGORY_DEFAULT);
            policy.addPersistentPreferredActivity(admin, home, new ComponentName(this, MainActivity.class));
            if (policy.isLockTaskPermitted(getPackageName())) startLockTask();
        } catch (SecurityException | IllegalStateException ignored) { }
        updateStatus();
    }
    private void stopDedicatedKiosk() {
        try { stopLockTask(); } catch (IllegalStateException | SecurityException ignored) { }
        if (isDeviceOwner()) {
            try {
                policy.clearPackagePersistentPreferredActivities(admin, getPackageName());
                policy.setLockTaskPackages(admin, new String[]{});
            } catch (SecurityException ignored) { }
        }
    }

    private void promptForAdminPin() {
        if (!prefs.contains("pin_hash")) { renderSettings(); return; }
        final EditText entry = new EditText(this);
        entry.setSingleLine(true);
        entry.setInputType(0x00000002 | 0x00000010); // number + password
        entry.setHint("Administrator-PIN");
        LinearLayout wrap = vertical();
        wrap.setPadding(dp(24), dp(8), dp(24), 0);
        wrap.addView(entry);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Stadt NexVerse · Administration")
                .setMessage("Bitte Administrator-PIN eingeben.")
                .setView(wrap)
                .setNegativeButton("Abbrechen", (d, which) -> { })
                .setPositiveButton("Entsperren", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (checkPin(entry.getText().toString())) {
                dialog.dismiss();
                stopDedicatedKiosk();
                renderSettings();
            } else entry.setError("PIN nicht korrekt");
        }));
        dialog.show();
    }

    private void renderSettings() {
        showingSettings = true;
        stopDedicatedKiosk();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout body = vertical();
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setPadding(dp(35), dp(18), dp(35), dp(25));
        scroll.addView(body);
        setContentView(scroll);
        immersive();
        TextView title = text("STADT NEXVERSE   /   KIOSK-VERWALTUNG", 24, PALE, true);
        body.addView(title);
        TextView description = text("HTTPS-Statistikquelle, Administrator-PIN und Gerätesperre konfigurieren", 13, MUTED, false);
        LinearLayout.LayoutParams descrP = lp(-1, 43);
        body.addView(description, descrP);
        TextView apiLabel = text("World API – Statistik-URL (HTTPS)", 13, CYAN, true);
        body.addView(apiLabel);
        EditText api = new EditText(this);
        api.setSingleLine(true);
        api.setTextColor(PALE);
        api.setHintTextColor(MUTED);
        api.setTextSize(15);
        api.setHint("https://DEIN-SERVER/api/v1/statistics/summary");
        api.setInputType(0x00000011); // textUri
        api.setText(prefs.getString("api_url", ""));
        body.addView(api, lp(-1, 56));
        TextView pinLabel = text(prefs.contains("pin_hash") ? "Neue PIN (leer = vorhandene beibehalten)" : "Administrator-PIN festlegen (mindestens 6 Ziffern)", 13, CYAN, true);
        LinearLayout.LayoutParams pinLP = lp(-1, 32);
        pinLP.topMargin = dp(12);
        body.addView(pinLabel, pinLP);
        EditText pin = new EditText(this);
        pin.setSingleLine(true);
        pin.setInputType(0x00000002 | 0x00000010);
        pin.setTextColor(PALE);
        pin.setHint("PIN mit 6 oder mehr Ziffern");
        pin.setHintTextColor(MUTED);
        body.addView(pin, lp(-1, 50));
        CheckBox enable = new CheckBox(this);
        enable.setText("Kiosk-Modus aktivieren (Device Owner: echte Sperre)");
        enable.setTextColor(PALE);
        enable.setTextSize(14);
        enable.setChecked(prefs.getBoolean("kiosk_enabled", true));
        LinearLayout.LayoutParams checkLP = lp(-1, 48);
        checkLP.topMargin = dp(4);
        body.addView(enable, checkLP);
        TextView status = text(isDeviceOwner()
                ? "Gerätestatus: Device Owner – Sperrmodus verfügbar"
                : "Gerätestatus: kein Device Owner – nur Vollbild/Bildschirmfixierung", 12,
                isDeviceOwner() ? GREEN : AMBER, false);
        body.addView(status, lp(-1, 38));
        Button start = new Button(this);
        start.setText("SPEICHERN UND DASHBOARD STARTEN");
        start.setTextColor(BG);
        start.setBackground(rounded(CYAN, 0, 12));
        LinearLayout.LayoutParams buttonLP = lp(-1, 54);
        buttonLP.topMargin = dp(10);
        body.addView(start, buttonLP);
        start.setOnClickListener(v -> {
            String validated = validatedUrl(api.getText().toString());
            if (validated == null) { api.setError("Bitte eine gültige HTTPS-URL eingeben."); return; }
            String digits = pin.getText().toString();
            if (!prefs.contains("pin_hash") || !digits.isEmpty()) {
                if (!digits.matches("[0-9]{6,16}")) {
                    pin.setError("6 bis 16 Ziffern erforderlich"); return;
                }
                storePin(digits);
            }
            prefs.edit().putString("api_url", validated)
                    .putBoolean("kiosk_enabled", enable.isChecked()).apply();
            initialSetup = false;
            online = false;
            lastUpdateMillis = 0;
            for (int i = 0; i < lastValues.length; i++) lastValues[i] = "—";
            renderDashboard();
            if (enable.isChecked() && !isDeviceOwner()) {
                new AlertDialog.Builder(this)
                        .setTitle("Bildschirmfixierung")
                        .setMessage("Ohne Device Owner ist keine sichere App-Sperre möglich. Soll Android die Bildschirmfixierung anbieten?")
                        .setNegativeButton("Nein", (d, w) -> { })
                        .setPositiveButton("Fixieren", (d, w) -> {
                            try { startLockTask(); } catch (RuntimeException ignored) { }
                        }).show();
            }
        });
        if (!initialSetup) {
            Button exit = new Button(this);
            exit.setText("KIOSK DEAKTIVIEREN UND APP SCHLIESSEN");
            exit.setTextColor(PALE);
            exit.setBackground(rounded(PANEL, Color.rgb(64, 88, 116), 12));
            LinearLayout.LayoutParams exitLP = lp(-1, 50);
            exitLP.topMargin = dp(14);
            body.addView(exit, exitLP);
            exit.setOnClickListener(v -> {
                prefs.edit().putBoolean("kiosk_enabled", false).apply();
                stopDedicatedKiosk();
                finish();
            });
        }
    }

    private String validatedUrl(String input) {
        try {
            String text = input.trim();
            Uri uri = Uri.parse(text);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null ||
                    uri.getHost().trim().isEmpty() || uri.getUserInfo() != null ||
                    uri.getQuery() != null || uri.getFragment() != null) return null;
            if (uri.getPort() != -1 && (uri.getPort() < 1 || uri.getPort() > 65535)) return null;
            if (text.endsWith("/")) text = text.substring(0, text.length() - 1);
            if (text.endsWith("/api/v1")) text += "/statistics/summary";
            else if (!text.endsWith("/api/v1/statistics/summary")) {
                if (!uri.getPath().isEmpty() && !"/".equals(uri.getPath())) return null;
                text += "/api/v1/statistics/summary";
            }
            return text;
        } catch (Exception ignored) { return null; }
    }

    private void storePin(String pin) {
        try {
            byte[] salt = new byte[24];
            new SecureRandom().nextBytes(salt);
            byte[] hash = hashPin(pin, salt);
            prefs.edit().putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                    .putString("pin_hash", Base64.encodeToString(hash, Base64.NO_WRAP)).apply();
        } catch (Exception e) { throw new IllegalStateException("PIN konnte nicht gespeichert werden", e); }
    }
    private boolean checkPin(String candidate) {
        try {
            byte[] salt = Base64.decode(prefs.getString("pin_salt", ""), Base64.DEFAULT);
            byte[] stored = Base64.decode(prefs.getString("pin_hash", ""), Base64.DEFAULT);
            return MessageDigest.isEqual(stored, hashPin(candidate, salt));
        } catch (Exception e) { return false; }
    }
    private byte[] hashPin(String pin, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(pin.toCharArray(), salt, 120000, 256);
        try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).getEncoded(); }
        finally { spec.clearPassword(); }
    }

    @Override public void onBackPressed() {
        if (showingSettings && !initialSetup) { renderDashboard(); return; }
        if (!prefs.getBoolean("kiosk_enabled", false)) { super.onBackPressed(); }
    }

    private static final class CityBackdrop extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        CityBackdrop(Context context) { super(context); }
        @Override protected void onDraw(Canvas canvas) {
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            paint.setShader(new LinearGradient(0, 0, w, h,
                    Color.rgb(6, 17, 35), Color.rgb(10, 31, 52), Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(null);
            paint.setColor(Color.argb(75, 24, 96, 130));
            float[] heights = { .12f, .18f, .09f, .25f, .13f, .16f, .32f, .22f,
                    .1f, .2f, .15f, .28f, .12f, .19f, .09f, .14f, .26f, .16f };
            float bw = w / heights.length;
            for (int i = 0; i < heights.length; i++) {
                float top = h * (1 - heights[i]);
                canvas.drawRect(i * bw + 2, top, (i + 1) * bw - 2, h, paint);
            }
            paint.setColor(Color.argb(34, 73, 214, 233));
            for (int i = 0; i < 14; i++) {
                float y = h * (.62f + i * .025f);
                canvas.drawLine(0, y, w, y, paint);
            }
        }
    }
}
