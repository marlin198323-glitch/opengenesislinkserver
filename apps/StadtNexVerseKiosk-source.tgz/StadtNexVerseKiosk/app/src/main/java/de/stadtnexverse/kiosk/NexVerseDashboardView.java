package de.stadtnexverse.kiosk;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Neon kiosk UI: all counters and chart data are supplied by the live World API. */
public class NexVerseDashboardView extends View {
    public interface AdminAction { void openAdmin(); }
    private static final int BASE_W = 1600, BASE_H = 1000;
    private static final int BG = 0xff050d24;
    private static final int WHITE = 0xfff0f7ff;
    private static final int MUTED = 0xffa1bad9;
    private static final int BLUE = 0xff16acff;
    private static final int CYAN = 0xff3bdffd;
    private static final int GOLD = 0xffffb23b;
    private static final int MAGENTA = 0xffd37bff;
    private static final int GREEN = 0xff78f74c;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Bitmap hero;
    private final AdminAction adminAction;
    private final ArrayList<Integer> residentHistory = new ArrayList<>();
    private final ArrayList<Integer> totalHistory = new ArrayList<>();
    private final ArrayList<Long> timeHistory = new ArrayList<>();
    private final TimeZone timezone = TimeZone.getTimeZone("Europe/Berlin");
    private String[] values = new String[13];
    private boolean connected, deviceOwner, kioskEnabled;
    private int healthState; // 0: unknown, 1: HTTP 200, -1: unavailable
    private long lastUpdateMs, latencyMs;
    private String connectionError = "";
    private int activeTab = 0;
    private float downX, downY;
    private long downAt;

    public NexVerseDashboardView(Context c, AdminAction action) {
        super(c);
        this.adminAction = action;
        hero = BitmapFactory.decodeResource(getResources(), R.drawable.hero_nexverse);
        for (int i=0;i<values.length;i++) values[i] = "—";
        setLayerType(View.LAYER_TYPE_SOFTWARE, null); // consistent glow on older Lenovo tablets
    }

    public void updateData(String[] data, boolean online, long updateAt, long latency,
                           String error, boolean isOwner, boolean enabled, int apiHealth) {
        if (data != null) values = data.clone();
        connected = online;
        lastUpdateMs = updateAt;
        latencyMs = latency;
        connectionError = error == null ? "" : error;
        deviceOwner = isOwner;
        kioskEnabled = enabled;
        healthState = apiHealth;
        invalidate();
    }

    public void appendSample(int residents, int total, long timeMs) {
        if (!timeHistory.isEmpty() && timeHistory.get(timeHistory.size()-1) >= timeMs) return;
        residentHistory.add(residents);
        totalHistory.add(total);
        timeHistory.add(timeMs);
        while (timeHistory.size()>32) {
            residentHistory.remove(0); totalHistory.remove(0); timeHistory.remove(0);
        }
        invalidate();
    }

    private static int alpha(int color, int opacity) { return (color & 0x00ffffff) | ((opacity & 255) << 24); }
    private void rect(Canvas c,float l,float t,float r,float b,float radius,int fill,int stroke) {
        p.clearShadowLayer(); p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(fill);
        c.drawRoundRect(new RectF(l,t,r,b),radius,radius,p);
        if (stroke != 0) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(stroke);
            c.drawRoundRect(new RectF(l+1,t+1,r-1,b-1),radius,radius,p);
            p.setStyle(Paint.Style.FILL);
        }
    }
    private void gradientPanel(Canvas c,float l,float t,float r,float b,int accent) {
        rect(c,l,t,r,b,17,0xff091c3e,alpha(accent,160));
        p.setShader(new LinearGradient(l,t,l,b,0x8a174b7a,0x20142f58,Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(l+3,t+3,r-3,b-3),15,15,p);
        p.setShader(null);
        p.setColor(alpha(accent, 150)); p.setStrokeWidth(4);
        c.drawLine(l+22,t+2,l+Math.min(95,(r-l)*0.34f),t+2,p);
        p.setColor(alpha(accent, 80)); c.drawLine(r-90,b-2,r-20,b-2,p);
    }
    private void text(Canvas c,String s,float x,float y,float size,int color,boolean bold) {
        p.clearShadowLayer(); p.setShader(null); p.setStyle(Paint.Style.FILL);
        p.setColor(color); p.setTextSize(size);
        p.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        p.setTextAlign(Paint.Align.LEFT);
        c.drawText(s,x,y,p);
    }
    private void center(Canvas c,String s,float x,float y,float size,int color,boolean bold) {
        p.clearShadowLayer(); p.setShader(null); p.setColor(color);
        p.setTextSize(size); p.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        p.setTextAlign(Paint.Align.CENTER);
        c.drawText(s,x,y,p);
        p.setTextAlign(Paint.Align.LEFT);
    }
    private String v(int i) { return i < values.length && values[i] != null ? values[i] : "—"; }
    private String fmt(long epoch,String format) {
        SimpleDateFormat f = new SimpleDateFormat(format,Locale.GERMANY);
        f.setTimeZone(timezone);
        return f.format(new Date(epoch));
    }
    @Override protected void onDraw(Canvas real) {
        super.onDraw(real);
        if (getWidth()<=0 || getHeight()<=0) return;
        real.save(); real.scale(getWidth()/(float)BASE_W,getHeight()/(float)BASE_H);
        real.drawColor(BG);
        if (hero!=null) {
            p.setColor(Color.WHITE); p.setAlpha(255); p.setFilterBitmap(true);
            real.drawBitmap(hero,null,new RectF(0,0,BASE_W,448),p);
            p.setAlpha(255);
        }
        p.setShader(new LinearGradient(0,390,0,468,0x00050d24,0xff050d24,Shader.TileMode.CLAMP));
        real.drawRect(0,390,1600,470,p); p.setShader(null);
        // A tiny independent API indicator is allowed even before data loads.
        rect(real,1312,395,1580,437,20,0xd8091c3d,connected?alpha(GREEN,180):alpha(GOLD,170));
        p.setColor(connected?GREEN:GOLD); real.drawCircle(1336,416,7,p);
        text(real,connected?"LIVE VERBUNDEN":"WARTE AUF WORLD API",1352,424,17,connected?GREEN:GOLD,true);
        drawMetric(real,0,"BEWOHNER ONLINE",v(0),BLUE);
        drawMetric(real,1,"HYPERGRID ONLINE",v(1),CYAN);
        drawMetric(real,2,"GESAMT ONLINE",v(2),GOLD);
        drawMetric(real,3,"HEIMATGRIDS ONLINE",v(5),BLUE);
        drawMetric(real,4,"REGISTRIERTE BEWOHNER",v(3),MAGENTA);
        drawMetric(real,5,"STATUS",connected?"ONLINE":"OFFLINE",connected?GREEN:GOLD);
        drawClock(real);
        drawCenterPanel(real);
        drawServicePanel(real);
        drawFooter(real);
        real.restore();
    }
    private void drawMetric(Canvas c,int index,String title,String value,int color) {
        float gap=10, width=(1576f-24f-5f*gap)/6f;
        float left=24+index*(width+gap),right=left+width;
        gradientPanel(c,left,454,right,598,index==2?GOLD:color);
        p.setColor(alpha(color,190));
        c.drawCircle(left+27,483,8,p); c.drawCircle(left+38,483,5,p);
        center(c,title,(left+right)/2,516,title.length()>21?16:19,WHITE,true);
        float f=value.length()>7?40:value.length()>5?48:64;
        center(c,value,(left+right)/2,575,f,color,true);
    }
    private void drawClock(Canvas c) {
        gradientPanel(c,24,610,452,857,CYAN);
        text(c,"◷  AKTUELLE UHRZEIT",50,652,25,WHITE,true);
        text(c,fmt(System.currentTimeMillis(),"HH:mm:ss"),48,759,79,WHITE,true);
        text(c,fmt(System.currentTimeMillis(),"EEEE, d. MMMM yyyy"),52,811,22,MUTED,true);
        text(c,"EUROPA / BERLIN",52,843,15,CYAN,true);
    }
    private void drawCenterPanel(Canvas c) {
        gradientPanel(c,466,610,1175,857,BLUE);
        final String[] tabs={"Übersicht","Regionen","Bewohner","Dienste","Statistiken","Mehr"};
        if (activeTab!=0) {
            text(c,tabs[activeTab].toUpperCase(Locale.GERMANY),497,656,26,WHITE,true);
            drawTabDetails(c);
            return;
        }
        text(c,"▥  LIVE-AKTIVITÄT",493,651,26,WHITE,true);
        p.setColor(CYAN);c.drawCircle(946,642,7,p);text(c,"Bewohner",960,650,17,WHITE,false);
        p.setColor(GOLD);c.drawCircle(1075,642,7,p);text(c,"Gesamt",1089,650,17,WHITE,false);
        float l=512, r=1146,t=677,b=809;
        for(int i=0;i<=4;i++) {
            float yy=t+(b-t)*i/4f;
            p.setColor(0x3437a6d7); p.setStrokeWidth(1); c.drawLine(l,yy,r,yy,p);
        }
        if(timeHistory.size()<2) {
            center(c,"Diagramm startet nach den ersten Live-Messungen",(l+r)/2,744,19,MUTED,false);
        } else {
            int max=5;
            for(int value:totalHistory)max=Math.max(max,value);
            max=(int)(Math.ceil(max/5.0)*5);
            drawSeries(c,residentHistory,CYAN,l,r,t,b,max);
            drawSeries(c,totalHistory,GOLD,l,r,t,b,max);
            text(c,Integer.toString(max),480,t+5,14,MUTED,false);
            text(c,"0",493,b+5,14,MUTED,false);
            text(c,fmt(timeHistory.get(0),"HH:mm"),515,837,15,MUTED,false);
            text(c,fmt(timeHistory.get(timeHistory.size()-1),"HH:mm"),1086,837,15,MUTED,false);
        }
    }
    private void drawSeries(Canvas c,ArrayList<Integer> nums,int accent,float l,float r,float t,float b,int max) {
        Path path = new Path();
        for(int i=0;i<nums.size();i++) {
            float x=l+(r-l)*i/Math.max(1,nums.size()-1);
            float y=b-(b-t)*nums.get(i)/(float)max;
            if(i==0)path.moveTo(x,y);else path.lineTo(x,y);
        }
        p.setColor(accent);p.setStrokeWidth(4);p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);
        c.drawPath(path,p);p.setStyle(Paint.Style.FILL);
        int last=nums.size()-1;
        p.setColor(accent);c.drawCircle(r,b-(b-t)*nums.get(last)/(float)max,5,p);
    }
    private void drawTabDetails(Canvas c) {
        String[][] rows;
        switch(activeTab) {
            case 1: rows=new String[][]{{"Heimatgrids derzeit online",v(5)},
                    {"Bekannte Herkunftsgrids",v(9)},
                    {"Aktive Regionen", "Nicht in öffentlicher Statistik"}};break;
            case 2: rows=new String[][]{{"Einwohner online",v(0)},
                    {"Registrierte Einwohner",v(3)},
                    {"In den letzten 24 Stunden aktiv",v(6)}};break;
            case 3: rows=new String[][]{{"World API",healthState==1?"HTTP 200":healthState==-1?"Nicht erreichbar":"Nicht geprüft"},
                    {"Statistik-Schnittstelle",connected?"Verbunden":"Nicht verbunden"},
                    {"Weitere Dienste","Einzelstatus nicht verfügbar"}};break;
            case 4: rows=new String[][]{{"Einwohner aktiv (7 Tage)",v(7)},
                    {"Hypergrid-Besucher (7 Tage)",v(8)},
                    {"Neuregistrierungen (7 Tage)",v(10)}};break;
            default: rows=new String[][]{{"Verwaltung","STADT NEXVERSE oben links lange halten"},
                    {"Gerätemodus",deviceOwner?"Device Owner":"Nur Vollbild"},
                    {"Kiosk aktiviert",kioskEnabled?"Ja":"Nein"}};
        }
        for(int i=0;i<rows.length;i++) {
            float y=699+56*i;
            text(c,rows[i][0],500,y,19,MUTED,false);
            text(c,rows[i][1],805,y,19,i==2?CYAN:WHITE,true);
            p.setColor(0x3343b9fc);p.setStrokeWidth(1);c.drawLine(498,y+16,1142,y+16,p);
        }
    }
    private void drawServicePanel(Canvas c) {
        gradientPanel(c,1188,610,1576,857,CYAN);
        text(c,"◇  WORLD API",1212,652,25,WHITE,true);
        p.setColor(connected?GREEN:GOLD);c.drawCircle(1228,684,8,p);
        text(c,connected?"Verbunden":"Nicht verbunden",1248,691,21,connected?GREEN:GOLD,true);
        if(connected && latencyMs>0) text(c,latencyMs+" ms",1480,690,15,MUTED,false);
        p.setColor(0x6659baff);p.setStrokeWidth(1);c.drawLine(1211,709,1551,709,p);
        serviceRow(c,735,"Statistik",connected?"OK":"FEHLER",connected);
        serviceRow(c,772,"API Health",healthState==1?"OK":healthState==-1?"FEHLER":"—",healthState==1);
        serviceRow(c,809,"Grid Service","—",false);
        serviceRow(c,846,"Asset Service","—",false);
    }
    private void serviceRow(Canvas c,int y,String label,String value,boolean healthy) {
        p.setColor(healthy?GREEN:MUTED); c.drawCircle(1227,y-6,6,p);
        text(c,label,1245,y,19,WHITE,false);
        text(c,value,1497,y,18,healthy?GREEN:MUTED,true);
    }
    private void drawFooter(Canvas c) {
        rect(c,23,873,1576,966,18,0xff071a36,0xff1c7dbb);
        String last;
        if(lastUpdateMs==0)last="Noch keine Statistikdaten";
        else last=(connected?"Letzte Aktualisierung: ":"Verbindung getrennt · Letzte Daten: ")+fmt(lastUpdateMs,"HH:mm:ss");
        if(!connected && !connectionError.isEmpty()) last="API-Fehler: "+connectionError;
        if(last.length()>48) last=last.substring(0,46)+"…";
        text(c,"⟳  Aktualisierung alle 15 Sekunden",41,910,20,CYAN,true);
        text(c,last,41,946,17,connected?MUTED:GOLD,false);
        String[] names={"Übersicht","Regionen","Bewohner","Dienste","Statistiken","Mehr"};
        String[] symbols={"⌂","▱","♟","⚙","▥","•••"};
        float left=654, gap=8, width=146;
        for(int i=0;i<6;i++) {
            float x=left+i*(width+gap);
            rect(c,x,883,x+width,952,10,i==activeTab?0xff663815:0xff092449,
                    i==activeTab?GOLD:0xff1b87c8);
            center(c,symbols[i],x+width/2,910,27,i==activeTab?GOLD:CYAN,true);
            center(c,names[i],x+width/2,938,16,WHITE,true);
        }
    }
    @Override public boolean onTouchEvent(MotionEvent event) {
        float x=event.getX()*BASE_W/Math.max(1,getWidth());
        float y=event.getY()*BASE_H/Math.max(1,getHeight());
        switch(event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downAt=SystemClock.elapsedRealtime();downX=x;downY=y;return true;
            case MotionEvent.ACTION_UP:
                if(downX<565 && downY<370 && SystemClock.elapsedRealtime()-downAt>=650) {
                    adminAction.openAdmin();return true;
                }
                if(y>=872&&y<=976&&x>=650) {
                    int i=(int)((x-654)/(146+8));
                    if(i>=0&&i<6) {
                        activeTab=i;invalidate();
                        if(i==5)performClick();return true;
                    }
                }
                return true;
            default:return true;
        }
    }
    @Override public boolean performClick() { super.performClick(); return true; }
}
